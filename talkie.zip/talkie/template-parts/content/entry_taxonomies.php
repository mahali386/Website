<?php

/**
 * Template part for displaying a post's taxonomy terms
 *
 * @package talkie
 */

namespace Talkie\Talkie;

$taxonomies = wp_list_filter(
	get_object_taxonomies($post, 'objects'),
	array(
		'public' => true,
	)
);

?>
<ul class="talkie-blogtag list-inline">
	<li class="talkie-comment-count">
		<?php
		$comments_number = get_comments_number();
		echo esc_html($comments_number);
		if ($comments_number == 1) {
			_e(' Comment', 'talkie');
		} else {
			_e(' Comments', 'talkie');
		}
		?>
	</li>
	<?php
	$post_tag = get_the_tags();
	if ($post_tag) { ?>

		<?php foreach ($post_tag as $tag) { ?>
			<li><a href="<?php echo get_tag_link($tag->term_id); ?>"><?php echo esc_html($tag->name); ?></a></li>
		<?php } ?>
	<?php }
	?>
</ul>