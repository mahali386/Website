<?php
/**
 * Template part for displaying a pagination
 *
 * @package talkie
 */

namespace Talkie\Talkie;

talkie()->talkie_pagination();
