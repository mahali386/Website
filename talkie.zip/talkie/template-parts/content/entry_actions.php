<?php
/**
 * Template part for displaying a post's comment and edit links
 *
 * @package talkie
 */

namespace Talkie\Talkie;

?>
<div class="entry-actions">
	<?php talkie()->talkie_get_blog_readmore_link(get_the_permalink(), 'Read More'); ?>
</div><!-- .entry-actions -->
