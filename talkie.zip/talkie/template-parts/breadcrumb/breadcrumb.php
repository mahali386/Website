<?php

/**
 * Template part for displaying the Breadcrumb 
 *
 * @package talkie
 */

namespace Talkie\Talkie;

if (is_front_page()) {
        if (is_home()) { ?>
            <div class="talkie-breadcrumb-one text-center green-bg">
                <div class="container">
                    <div class="row flex-row-reverse">
                        <div class="col-sm-12">
                            <div class="heading-title white talkie-breadcrumb-title">
                                <h1 class="title"><?php esc_html_e('Home', 'talkie'); ?></h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<?php }
}
talkie()->talkie_inner_breadcrumb();
?>