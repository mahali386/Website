<?php

/**
 * Template part for displaying the footer info
 *
 * @package talkie
 */

namespace Talkie\Talkie;

if (class_exists('ReduxFramework')) {

	$talkie_options = get_option('talkie-options');
?>
	<div class="copyright-footer">
		<div class="container">
			<div class="row">
				<?php if (isset($talkie_options['display_copyright']) && $talkie_options['display_copyright'] == 'yes') {  ?>
					<div class="col-sm-12 m-0 text-<?php echo esc_attr($talkie_options['footer_copyright_align']); ?>">
						<div class="pt-3 pb-3">
							<?php
							if (isset($talkie_options['footer_copyright'])) {  ?>
								<span class="copyright"><?php echo html_entity_decode($talkie_options['footer_copyright']); ?></span>
							<?php
							} else {	?>
								<span class="copyright"><a target="_blank" href="<?php echo esc_url(__('https://iqonic.design/', 'talkie')); ?>"> <?php printf(esc_html__('© 2022', 'talkie'), 'talkie'); ?><strong><?php printf(esc_html__(' talkie ', 'talkie'), 'talkie'); ?></strong><?php printf(esc_html__('. All Rights Reserved.', 'talkie'), 'talkie'); ?></a></span>
							<?php
							} ?>
						</div>
					</div>
				<?php } ?>
			</div>
		</div>
	</div><!-- .site-info -->

<?php } else { ?>

	<div class="copyright-footer">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div class="pt-3 pb-3">
						<span class="copyright"><a target="_blank" href="<?php echo esc_url(__('https://iqonic.design/', 'talkie')); ?>"> <?php printf(esc_html__('© 2022', 'talkie'), 'talkie'); ?><strong><?php printf(esc_html__(' talkie ', 'talkie'), 'talkie'); ?></strong><?php printf(esc_html__('. All Rights Reserved.', 'talkie'), 'talkie'); ?></a></span>
					</div>
				</div>
			</div>
		</div>
	</div><!-- .site-info -->
<?php }
