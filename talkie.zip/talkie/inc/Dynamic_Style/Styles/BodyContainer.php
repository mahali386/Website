<?php
/**
 * Talkie\Talkie\Dynamic_Style\Styles\BodyContainer class
 *
 * @package talkie
 */

namespace Talkie\Talkie\Dynamic_Style\Styles;

use Talkie\Talkie\Dynamic_Style\Component;
use function add_action;

class BodyContainer extends Component
{

	public function __construct()
	{
		if (class_exists('ReduxFramework')) {
			add_action('wp_enqueue_scripts', array( $this,'talkie_container_width'), 21);
		}
	}

	public function talkie_container_width()
	{
		$talkie_options = get_option('talkie-options');

		$box_container_width = "";

		if (isset($talkie_options['opt-slider-label']) && !empty($talkie_options['opt-slider-label'])) {

			$container_width = $talkie_options['opt-slider-label'];

			$box_container_width = "body.iq-container-width .container,
        							body.iq-container-width .elementor-section.elementor-section-boxed>
        							.elementor-container { max-width: " . $container_width . "px; } ";
		}


		wp_add_inline_style('talkie-style',
			$box_container_width
		);
	}
}
