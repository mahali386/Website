<?php

/**
 * Talkie\Talkie\Dynamic_Style\Styles\Footer class
 *
 * @package talkie
 */

namespace Talkie\Talkie\Dynamic_Style\Styles;

use Talkie\Talkie\Dynamic_Style\Component;
use function add_action;

class Footer extends Component
{

	public function __construct()
	{
		add_action('wp_enqueue_scripts', array($this, 'talkie_footer_dynamic_style'), 20);
	}

	public function talkie_footer_dynamic_style()
	{

		$page_id = get_queried_object_id();
		$talkie_options = get_option('talkie-options');
		$footer_css = '';
		if (isset($talkie_options['footer_top'])) {

			if ($talkie_options['footer_top'] == 'no') {
				$footer_css = '.footer-top { 
					display : none !important;
				}';
			}
		}

		if (isset($talkie_options['change_footer_color'])) {

			if (isset($talkie_options['footer_bg_color']) && $talkie_options['change_footer_color'] == '0') {
				$footer_bg_color = $talkie_options['footer_bg_color'];
				$footer_css .= ".footer {
					background-color: $footer_bg_color !important;
				}";
			}
		}
	

		wp_add_inline_style('talkie-global', $footer_css);
	}
}
