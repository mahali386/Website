<?php

/**
 * Talkie\Talkie\Dynamic_Style\Styles\General class
 *
 * @package talkie
 */

namespace Talkie\Talkie\Dynamic_Style\Styles;

use Talkie\Talkie\Dynamic_Style\Component;
use function add_action;

class General extends Component
{
	public function __construct()
	{

		add_action('wp_enqueue_scripts', array($this, 'talkie_create_general_style'), 20);
	}

	public function talkie_create_general_style()
	{

		$talkie_option = get_option('talkie-options');
		$general_var = ':root { ';

		if (isset($talkie_option['grid_container']) && !empty($talkie_option['grid_container'])) {
			$general = $talkie_option['grid_container']['width'];
			$general_var .= ' --content-width: ' . $general . ' !important;';
		}
		$general_var .= '}';
		if (isset($talkie_option['body_set_option']) && $talkie_option['body_set_option'] == 1) {
			if (
				isset($talkie_option['body_color'])  && !empty($talkie_option['body_color'])
			) {
				$general = $talkie_option['body_color'];
				$general_var .= ' body { background : ' . $general . ' !important; }';
			}
		}
		if (isset($talkie_option['body_set_option']) && $talkie_option['body_set_option'] == 3) {
			if (isset($talkie_option['body_image']['url']) && !empty($talkie_option['body_image']['url'])) {
				$general = $talkie_option['body_image']['url'];
				$general_var .= '
					body { background-image: url(' . $general . ') !important; }';
			}
		}

		if (isset($talkie_option['back_to_top_btn']) && $talkie_option['back_to_top_btn'] == 'no') {
			if (isset($talkie_option['back_to_top_btn']) && !empty($talkie_option['back_to_top_btn'])) {
				$general_var .= '
					#back-to-top { display: none !important; }';
			}
		}

		wp_add_inline_style('talkie-global', $general_var);
	}
}
