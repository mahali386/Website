<?php

/**
 * Talkie\Talkie\Dynamic_Style\Styles\Banner class
 *
 * @package talkie
 */

namespace Talkie\Talkie\Dynamic_Style\Styles;

use Talkie\Talkie\Dynamic_Style\Component;
use function add_action;

class Color extends Component
{

	public function __construct()
	{
		add_action('wp_enqueue_scripts', array($this, 'talkie_color_options'), 20);
		add_action('wp_enqueue_scripts', array($this, 'talkie_banner_title_color'), 20);
		add_action('wp_enqueue_scripts', array($this, 'talkie_layout_color'), 20);
		add_action('wp_enqueue_scripts', array($this, 'talkie_loader_color'), 20);
		add_action('wp_enqueue_scripts', array($this, 'talkie_bg_color'), 20);
		add_action('wp_enqueue_scripts', array($this, 'talkie_opacity_color'), 20);
		add_action('wp_enqueue_scripts', array($this, 'talkie_header_radio'), 20);
		add_action('wp_enqueue_scripts', array($this, 'talkie_footer_color'), 20);
	}

	public function talkie_color_options()
	{

		$talkie_option = get_option('talkie-options');
		if (class_exists('ReduxFramework')) {
			$color_var = ':root { ';
			
			if (isset($talkie_option['custom_color_switch']) && $talkie_option['custom_color_switch'] == 'yes' && isset($talkie_option['primary_color']) && !empty($talkie_option['primary_color'])) {
				$color = $talkie_option['primary_color'];
				$color_var .= '--color-theme-primary: ' . $color . ' !important;';
			}

			if (isset($talkie_option['custom_color_switch']) && $talkie_option['custom_color_switch'] == 'yes' && isset($talkie_option['secondary_color']) && !empty($talkie_option['secondary_color'])) {
				$color = $talkie_option['secondary_color'];
				$color_var .= '--color-theme-secondary: ' . $color . ' !important;';
			}
			
			if (isset($talkie_option['custom_color_switch']) && $talkie_option['custom_color_switch'] == 'yes' && isset($talkie_option['text_color']) && !empty($talkie_option['text_color'])) {
				$color = $talkie_option['text_color'];
				$color_var .= '--global-font-color: ' . $color . ' !important;';
			}

			if (isset($talkie_option['custom_color_switch']) && $talkie_option['custom_color_switch'] == 'yes' && isset($talkie_option['title_color']) && !empty($talkie_option['title_color'])) {
				$color = $talkie_option['title_color'];
				$color_var .= ' --global-font-title: ' . $color . ' !important;';
			}

			$color_var .= '}';
			wp_add_inline_style('talkie-global', $color_var);
		}
	}

	public function talkie_banner_title_color()
	{
		//Set Body Color
		$talkie_option = get_option('talkie-options');

		if (!empty($talkie_option['bg_title_color'])) {
			$bg_title_color = $talkie_option['bg_title_color'];
		}

		$bn_title_color = "";

		if (!empty($bg_title_color)) {
			$bn_title_color .= "
        .talkie-breadcrumb-one .title{
            color: $bg_title_color !important;
        }";
		}
		wp_add_inline_style('talkie-global', $bn_title_color);
	}

	public function talkie_layout_color()
	{
		//Set Body Color
		$talkie_option = get_option('talkie-options');

		if (!empty($talkie_option['talkie_layout_color'])) {
			$talkie_layout_color = $talkie_option['talkie_layout_color'];
		}
		$body_accent_color = "";

		if (isset($body_back_color) && !empty($body_back_color)) {
			$body_accent_color .= "
        body {
            background-color: $body_back_color !important;
        }";
		} else if (!empty($talkie_option['layout_set']) && $talkie_option['layout_set'] == "1" && $key_body_bg_col['body_variation'] != 'default') {
			if (!empty($talkie_layout_color) && $talkie_layout_color != '#ffffff') {
				$body_accent_color .= "
            body {
                background-color: $talkie_layout_color !important;
            }";
			}
		} else {
			$body_accent_color = "";
		}

		wp_add_inline_style('talkie-style', $body_accent_color);
	}

	public function talkie_loader_color()
	{
		//Set Loader Background Color
		$talkie_option = get_option('talkie-options');

		if (!empty($talkie_option['loader_color'])) {
			$loader_color = $talkie_option['loader_color'];
		}
		$ld_color = "";

		if (!empty($loader_color) && $loader_color != '#ffffff') {
			$ld_color .= "#loading {
								background : $loader_color !important;
							}";
		}
		wp_add_inline_style('talkie-style', $ld_color);
	}

	public function talkie_bg_color()
	{
		//Set Background Color
		$talkie_option = get_option('talkie-options');

		if (!empty($talkie_option['bg_color'])) {
			$bg_color = $talkie_option['bg_color'];
		}
		$background_color = "";

		if (!empty($talkie_option['bg_type']) && $talkie_option['bg_type'] == "1") {
			if (!empty($bg_color) && $bg_color != '#ffffff') {
				$background_color .= "
            .talkie-bg-over {
                background : $bg_color !important;
            }";
			}
		}
		wp_add_inline_style('talkie-style', $background_color);
	}

	public function talkie_opacity_color()
	{
		//Set Background Opacity Color
		$talkie_option = get_option('talkie-options');

		if (!empty($talkie_option['bg_opacity']) && $talkie_option['bg_opacity'] == "3") {
			$bg_opacity = $talkie_option['opacity_color']['rgba'];
		}
		$op_color = "";

		if (!empty($talkie_option['bg_opacity']) && $talkie_option['bg_opacity'] == "3") {
			if (!empty($bg_opacity) && $bg_opacity != '#ffffff') {
				$op_color .= "
        .breadcrumb-video::before,.breadcrumb-bg::before, .breadcrumb-ui::before {
            background : $bg_opacity !important;
        }";
			}
		}
		wp_add_inline_style('talkie-style', $op_color);
	}

	public function talkie_header_radio()
	{
		//Set Text Logo Color
		$talkie_option = get_option('talkie-options');

		if (!empty($talkie_option['header_color'])) {
			$logo = $talkie_option['header_color'];
		}
		$logo_color = "";

		if (!empty($talkie_option['header_radio']) && $talkie_option['header_radio'] == "1") {
			if (!empty($logo) && $logo != '#ffffff') {
				$logo_color .= "
            .logo-text {
                color : $logo !important;
            }";
			}
		}
		wp_add_inline_style('talkie-style', $logo_color);
	}

	public function talkie_footer_color()
	{
		//Set Footer Background Color
		$talkie_option = get_option('talkie-options');

		if (!empty($talkie_option['change_footer_color']) && $talkie_option['change_footer_color'] == "0") {
			$f_color = $talkie_option['footer_color'];
		}
		$footer_color = "";
		if (!empty($talkie_option['change_footer_color']) && $talkie_option['change_footer_color'] == "0") {
			if (!empty($f_color) && $f_color != '#ffffff') {
				$footer_color .= "
            .talkie-over-dark-90 {
                background : $f_color !important;
            }";
			}
		} else {
			$footer_color = '';
		}

		wp_add_inline_style('talkie-style', $footer_color);
	}
}
