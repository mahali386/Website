<?php

/**
 * Talkie\Talkie\Dynamic_Style\Styles\Banner class
 *
 * @package talkie
 */

namespace Talkie\Talkie\Dynamic_Style\Styles;

use Talkie\Talkie\Dynamic_Style\Component;
use function add_action;

class Banner extends Component
{

    public function __construct()
    {
        add_action('wp_enqueue_scripts', array($this, 'talkie_banner_dynamic_style'), 20);
        add_action('wp_enqueue_scripts', array($this, 'talkie_opacity_color'), 20);
        add_action('wp_enqueue_scripts', array($this, 'talkie_banner_hide'), 20);
    }

    public function talkie_banner_dynamic_style()
    {
        $page_id = get_queried_object_id();
        $talkie_options = get_option('talkie-options');
        $dynamic_css = '';

        if (isset($talkie_options['display_banner'])) {
            if ($talkie_options['display_banner'] == 'no') {
                $dynamic_css .=
                    '.talkie-breadcrumb-one { display: none !important; }
                    .content-area .site-main {padding : 0 !important; }';
            }
        }

        if (isset($talkie_options['display_title'])) {

            if ($talkie_options['display_title'] == 'no') {
                $dynamic_css .=
                    '.talkie-breadcrumb-one .title { display: none !important; }';
            }
        }

        if (isset($talkie_options['display_breadcumb'])) {

            if ($talkie_options['display_breadcumb'] == 'no') {
                $dynamic_css .=
                    '.talkie-breadcrumb-one .breadcrumb { display: none !important; }';
            }
        }

        if (isset($talkie_options['bg_title_color'])) {

            if ($talkie_options['bg_title_color'] == 'yes') {
                $dynamic = $talkie_options['bg_title_color'];
                $dynamic_css .=
                    '.talkie-breadcrumb-one .title { color: ' . $dynamic . ' !important; }';
            }
        }
        if (isset($talkie_options['bg_type'])) {
            $opt = $talkie_options['bg_type'];
            if ($opt == '1') {
                if (isset($talkie_options['bg_color']) && !empty($talkie_options['bg_color'])) {
                    $dynamic = $talkie_options['bg_color'];
                    $dynamic_css .=
                        '.talkie-breadcrumb-one { background: ' . $dynamic . ' !important; }';
                }
            }
            if ($opt == '2') {
                if (isset($talkie_options['banner_image']['url'])) {
                    $dynamic = $talkie_options['banner_image']['url'];
                    $dynamic_css .=
                        '.talkie-breadcrumb-one { background-image: url(' . $dynamic . ') !important; }';
                }
            }
        }

        wp_add_inline_style('talkie-global', $dynamic_css);
    }
    public function talkie_opacity_color()
    {
        //Set Background Opacity Color
        $talkie_options = get_option('talkie-options');

        if (!empty($talkie_options['bg_opacity']) && $talkie_options['bg_opacity'] == "3") {
            $bg_opacity = $talkie_options['opacity_color']['rgba'];
        }
        $dynamic_css = '';

        if (!empty($talkie_options['bg_opacity']) && $talkie_options['bg_opacity'] == "3") {
            if (!empty($bg_opacity) && $bg_opacity != '#ffffff') {
                $dynamic_css .= "
            .breadcrumb-video::before,.breadcrumb-bg::before, .breadcrumb-ui::before {
                background : $bg_opacity !important;
            }";
            }
        }
        wp_add_inline_style('talkie-global', $dynamic_css);
    }

    public function talkie_banner_hide()
    { 
        $talkie_options = get_option('talkie-options');
        $banner_hide = '';
        $pages = '';
        if(isset($talkie_options['pages_select'])){
            $pages = $talkie_options['pages_select'];
            foreach($pages as $data){

                $page = get_page_by_path( $data );
                if(isset($page)){
                    $banner_hide .= '.page-id-'.$page->ID.' .talkie-breadcrumb-one { display: none !important; }';
                }
    
            }
        }

        wp_add_inline_style('talkie-global', $banner_hide);
    }

}
