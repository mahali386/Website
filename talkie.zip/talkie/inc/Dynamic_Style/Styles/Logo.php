<?php
/**
 * Talkie\Talkie\Dynamic_Style\Styles\Logo class
 *
 * @package talkie
 */

namespace Talkie\Talkie\Dynamic_Style\Styles;

use Talkie\Talkie\Dynamic_Style\Component;
use function add_action;

class Logo extends Component
{

	public function __construct()
	{
		add_action('wp_enqueue_scripts', array($this, 'talkie_logo_options'), 20);
	}

	public function talkie_logo_options(){
        $talkie_options = get_option('talkie-options');
        $logo_var = '';
        if(isset($talkie_options['header_radio']) && $talkie_options['header_radio'] == 1){
            if(isset($talkie_options['header_color'])){
                $logo = $talkie_options['header_color'];
                    $logo_var .= "
                    .navbar-light .navbar-brand {
                        color : $logo !important;
                    }"; 
            }  
        }          
            wp_add_inline_style( 'talkie-global', $logo_var );
    }
}
