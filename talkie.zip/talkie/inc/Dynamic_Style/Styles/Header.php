<?php

/**
 * Talkie\Talkie\Dynamic_Style\Styles\Header class
 *
 * @package talkie
 */

namespace Talkie\Talkie\Dynamic_Style\Styles;

use Talkie\Talkie\Dynamic_Style\Component;
use function add_action;


class Header extends Component
{

	public function __construct()
	{
		add_action('wp_enqueue_scripts', array($this, 'talkie_header_background_style'), 20);
		add_action('wp_enqueue_scripts', array($this, 'talkie_menu_color_options'), 20);
		add_action('wp_enqueue_scripts', array($this, 'talkie_sub_menu_color_options'), 20);
		add_action('wp_enqueue_scripts', array($this, 'talkie_burger_menu_color_options'), 20);
		add_action('wp_enqueue_scripts', array($this, 'talkie_action_btn_color_options'), 20);
	}

	public function talkie_header_background_style()
	{
		$talkie_option = get_option('talkie-options');
		$dynamic_css = '';

		if (isset($talkie_option['talkie_header_background_type'])) {
			if (isset($talkie_option['talkie_header_background_type']) && $talkie_option['talkie_header_background_type'] != 'default') {
				$type = $talkie_option['talkie_header_background_type'];
				if ($type == 'color') {
					if (!empty($talkie_option['talkie_header_background_color'])) {
						$dynamic_css = 'header#default-header{
							background : ' . $talkie_option['talkie_header_background_color'] . '!important;
						}';
					}
				}
				if ($type == 'image') {
					if (!empty($talkie_option['talkie_header_background_image']['url'])) {
						$dynamic_css = 'header#default-header{
							background : url(' . $talkie_option['talkie_header_background_image']['url'] . ') !important;
						}';
					}
				}
				if ($type == 'transparent') {
					$dynamic_css = 'header#default-header{
						background : transparent !important;
					}';
				}
			}
		}
		wp_add_inline_style('talkie-global', $dynamic_css);
	}

	public function talkie_menu_color_options()
	{

		$talkie_option =  get_option('talkie-options');
		$inline_css = '';

		if (!empty($talkie_option['menu_color']) && $talkie_option['menu_color'] == "custom") {

			if (isset($talkie_option['header_menu_color']) && !empty($talkie_option['header_menu_color'])) {
				$inline_css .= '.sf-menu > li > a{
						color : ' . $talkie_option['header_menu_color'] . '!important;
					}';
			}

			if (isset($talkie_option['hover_menu_color']) && !empty($talkie_option['hover_menu_color'])) {
				$inline_css .= '.sf-menu li:hover > a,.sf-menu li.current-menu-ancestor > a,.sf-menu  li.current-menu-item > a{
						color : ' . $talkie_option['hover_menu_color'] . ' !important;
					}';
			}
		}



		wp_add_inline_style('talkie-global', $inline_css);
	}

	public function talkie_sub_menu_color_options()
	{
		$talkie_option = get_option('talkie-options');
		$inline_css = '';
		if (isset($talkie_option['header_submenu_color_type']) && $talkie_option['header_submenu_color_type'] == 'custom') {
			if (isset($talkie_option['submenu_color']) && !empty($talkie_option['submenu_color'])) {
				$inline_css .= '.sf-menu ul.sub-menu a{
                   		color : ' . $talkie_option['submenu_color'] . ' !important; }';
			}

			if (isset($talkie_option['hover_submenu_color']) && !empty($talkie_option['hover_submenu_color'])) {
				$inline_css .= '.sf-menu li.sfHover>a, .sf-menu li:hover>a,.sf-menu li.current-menu-ancestor>a, .sf-menu li.current-menu-item>a, .sf-menu ul>li.menu-item.current-menu-parent>a,.sf-menu ul li.current-menu-parent>a, .sf-menu ul li .sub-menu li.current-menu-item>a
                					{  color : ' . $talkie_option['hover_submenu_color'] . ' !important;  }';
			}

			if (isset($talkie_option['submenu_background_color']) && !empty($talkie_option['submenu_background_color'])) {
				$inline_css .= '.sf-menu ul.sub-menu li{
                   background : ' . $talkie_option['submenu_background_color'] . ' !important;  }';
			}

			if (isset($talkie_option['hover_submenu_bg_color']) && !empty($talkie_option['hover_submenu_bg_color'])) {
				$inline_css .= '.sf-menu ul.sub-menu li:hover,.sf-menu ul.sub-menu li.current-menu-item{
                   background : ' . $talkie_option['hover_submenu_bg_color'] . ' !important;   }';
			}
		}
		wp_add_inline_style('talkie-global', $inline_css);
	}

	public function talkie_burger_menu_color_options()
	{
		$talkie_option = get_option('talkie-options');
		$inline_css = '';

		if (isset($talkie_option['burger_menu_button_type']) && $talkie_option['burger_menu_button_type'] == 'custom') {

			if (isset($talkie_option['burger_menu_icon']) && !empty($talkie_option['burger_menu_icon'])) {
				$inline_css .= ' .menu-btn .line {
                    background-color : ' . $talkie_option['burger_menu_icon'] . ' !important;
                }';
			}

			if (isset($talkie_option['burger_menu_popup_bg']) && !empty($talkie_option['burger_menu_popup_bg'])) {
				$inline_css .= ' .talkie-mobile-menu {
                    background : ' . $talkie_option['burger_menu_popup_bg'] . ' !important;
                }';
			}
			

			if (isset($talkie_option['burger_menu_color']) && !empty($talkie_option['burger_menu_color'])) {
				$inline_css .= '.talkie-mobile-menu .navbar-nav > li > a, .talkie-mobile-menu .navbar-nav li > .toggledrop svg{ 
					color : ' . $talkie_option['burger_menu_color'] . ' !important;
				}';
			}


			if (isset($talkie_option['burger_hover_menu_color']) && !empty($talkie_option['burger_hover_menu_color'])) {
				$inline_css .= '.talkie-mobile-menu .navbar-nav li.current-menu-item > .toggledrop svg, .talkie-mobile-menu .navbar-nav li.current-menu-item > a, .talkie-mobile-menu .navbar-nav li .sub-menu li:hover > a, .talkie-mobile-menu .navbar-nav li:hover > .toggledrop svg, .talkie-mobile-menu .navbar-nav li:hover > a, .talkie-mobile-menu ul > li.current-menu-ancestor > .toggledrop svg, .talkie-mobile-menu ul > li.current-menu-ancestor > a, .talkie-mobile-menu ul li .sub-menu li.current-menu-item > a, .talkie-mobile-menu ul li .sub-menu li.menu-item.current-menu-ancestor > a{
			        color : ' . $talkie_option['burger_hover_menu_color'] . ' !important;
				}';
			}

			if (isset($talkie_option['burger_submenu_color']) && !empty($talkie_option['burger_submenu_color'])) {
				$inline_css .= '.talkie-mobile-menu .navbar-nav li .sub-menu li a , .talkie-mobile-menu .navbar-nav li .sub-menu li svg{
			        color : ' . $talkie_option['burger_submenu_color'] . ' !important;
				}';
			}
		}
		wp_add_inline_style('talkie-global', $inline_css);
	}

	public function talkie_action_btn_color_options()
	{
		$talkie_option = get_option('talkie-options');
		$inline_css = '';

		if (isset($talkie_option['button_color']) && $talkie_option['button_color'] == 'custom') {

			if (isset($talkie_option['button_bg_color']) && !empty($talkie_option['button_bg_color'])) {
				$inline_css .= '
            header .talkie-shop-btn-holder  #btn-search svg,header .search_count #btn-search{
                color : ' . $talkie_option['button_bg_color'] . ' !important;
            }';
			}
		}

		if (!empty($inline_css)) {
			wp_add_inline_style('talkie-global', $inline_css);
		}
	}
}
