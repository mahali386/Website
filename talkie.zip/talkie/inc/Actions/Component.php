<?php

/**
 * Talkie\Talkie\Actions\Component class
 *
 * @package talkie
 */

namespace Talkie\Talkie\Actions;

use Talkie\Talkie\Component_Interface;
use Talkie\Talkie\Templating_Component_Interface;
use function add_action;

/**
 * Class for managing comments UI.
 *
 * Exposes template tags:
 * * `talkie()->the_comments( array $args = array() )`
 *
 * @link https://wordpress.org/plugins/amp/
 */
class Component implements Component_Interface, Templating_Component_Interface
{
	/**
	 * Gets the unique identifier for the theme component.
	 *
	 * @return string Component slug.
	 */
	public function get_slug(): string
	{
		return 'actions';
	}
	public function initialize()
	{
	}
	/**
	 * Gets template tags to expose as methods on the Template_Tags class instance, accessible through `talkie()`.
	 *
	 * @return array Associative array of $method_name => $callback_info pairs. Each $callback_info must either be
	 *               a callable or an array with key 'callable'. This approach is used to reserve the possibility of
	 *               adding support for further arguments in the future.
	 */
	public function template_tags(): array
	{
		return array(
			'talkie_get_blog_readmore_link' => array($this, 'talkie_get_blog_readmore_link'),
			'talkie_get_blog_readmore' => array($this, 'talkie_get_blog_readmore'),
			'talkie_get_comment_btn' => array($this, 'talkie_get_comment_btn'),
			'talkie_get_comment_reply' => array($this, 'talkie_get_comment_reply'),
		);
	}

	//** Blog Read More Button Link **//
	public function talkie_get_blog_readmore_link()
	{
		echo '<div class="blog-button">		
				<a class="talkie-button talkie-button-link" href="' . get_the_permalink() . '">' . __('Read More', 'talkie') . ' 
					<span class="talkie-icon-right"><i class="fas fa-chevron-right"></i></span>
				</a>
			</div>';
	}


	//** Blog Read More Button **//
	public function talkie_get_blog_readmore($link, $btn_text)
	{
		echo '<div class="blog-button">		
				<a class="talkie-button" href="' . esc_url($link) . '">' . esc_html($btn_text) . ' 
					<span class="talkie-icon-right"><i class="fas fa-chevron-right"></i></span>
				</a>
			</div>';
	}


	//** Comment Submit Button **//
	public function talkie_get_comment_btn()
	{
		return '<button name="submit" type="submit" id="submit" class="submit talkie-button" value="' . __('Post Comment' . 'talkie') . '" >
				<span class="talkie-main-btn">
				<span class="text-btn">' . esc_html__('Post Comment', 'talkie') . '</span><span class="btn-aerrow"><i class="fas fa-chevron-right"></i></span></span>
				</button>';
	}

	//** Comment Reply Button **//
	public function talkie_get_comment_reply($depth)
	{
		if ($depth < get_option('thread_comments_depth') && comments_open()) {

			$reply_to = esc_html__("Reply to ", "talkie");
			$reply_to .= get_comment_author(); ?>

			<div class="reply talkie-reply talkie-button-style-2">
				<a rel="nofollow" class="comment-reply-link talkie-button" href="<?php get_comment_author_link(); ?>?replytocom=<?php comment_ID(); ?>#respond" data-commentid="<?php comment_ID(); ?>" data-postid="<?php the_ID(); ?>" data-belowelement="div-comment-<?php comment_ID(); ?>" data-respondelement="respond" data-replyto="<?php echo esc_attr($reply_to); ?>" aria-label="<?php echo esc_attr($reply_to); ?>">
					<?php echo __('Reply', 'talkie'); ?>
				</a>
			</div>
<?php }
	}
}
