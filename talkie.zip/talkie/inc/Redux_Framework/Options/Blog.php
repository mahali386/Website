<?php
/**
 * Talkie\Talkie\Redux_Framework\Options\Blog class
 *
 * @package talkie
 */

namespace Talkie\Talkie\Redux_Framework\Options;

use Redux;
use Talkie\Talkie\Redux_Framework\Component;

class Blog extends Component {

	public function __construct() {
		$this->set_widget_option();
	}

	protected function set_widget_option() {
		Redux::set_section( $this->opt_name, array(
			'title' => esc_html__( 'Blog', 'talkie' ),
			'id'    => 'blog',
			'icon'  => 'el el-quotes',
			'customizer_width' => '500px',
		) );

		Redux::set_section( $this->opt_name, array(
			'title' => esc_html__('General Blogs','talkie'),
			'id'    => 'blog-section',
			'subsection' => true,
			'desc'  => esc_html__('This section contains options for blog.','talkie'),
			'fields'=> array(

				array(
					'id'       => 'blog_default_banner_image',
					'type'     => 'media',
					'url'      => true,
					'title'    => esc_html__( 'Blog Page Default Banner Image','talkie'),
					'read-only'=> false,
					'default'  => array( 'url' => get_template_directory_uri() .'/assets/images/redux/banner.png' ),
					'subtitle' => esc_html__( 'Upload banner image for your Website. Otherwise blank field will be displayed in place of this section.','talkie').'<b>'.esc_html__("(Note:Only Display Banner Style Second & Third in Page Banner Setting)","talkie").'</b>',
				),

				array(
					'id'        => 'blog_setting',
					'type'      => 'image_select',
					'title'     => esc_html__( 'Blog page Setting','talkie' ),
					'subtitle'  => wp_kses( __( '<br />Choose among these structures (Right Sidebar, Left Sidebar, 1column, 2column and 3column) for your blog section.<br />To filling these column sections you should go to appearance > widget.<br />And put every widget that you want in these sections.','talkie' ), array( 'br' => array() ) ),
					'options'   => array(
						'1' => array( 'title' => esc_html__( 'One Columns','talkie' ), 'img' => get_template_directory_uri() . '/assets/images/redux//single-column.jpg' ),
						'2' => array( 'title' => esc_html__( 'Two Columns','talkie' ), 'img' => get_template_directory_uri() . '/assets/images/redux//two-column.jpg' ),
						'3' => array( 'title' => esc_html__( 'Three Columns','talkie' ), 'img' => get_template_directory_uri() . '/assets/images/redux//three-column.jpg' ),
						'4' => array( 'title' => esc_html__( 'Right Sidebar','talkie' ), 'img' => get_template_directory_uri() . '/assets/images/redux//right-side.jpg' ),
						'5' => array( 'title' => esc_html__( 'Left Sidebar','talkie' ), 'img' => get_template_directory_uri() . '/assets/images/redux//left-side.jpg' ),
					),
					'default'   => '4',
				),

				array(
					'id'        => 'display_pagination',
					'type'      => 'button_set',
					'title'     => esc_html__( 'Previous/Next Pagination','talkie'),
					'subtitle' => esc_html__( 'Turn on to display the previous/next post pagination for blog page.','talkie'),
					'options'   => array(
						'yes' => esc_html__('On','talkie'),
						'no' => esc_html__('Off','talkie')
					),
					'default'   => esc_html__('yes','talkie')
				),

				array(
					'id'        => 'display_featured_image',
					'type'      => 'button_set',
					'title'     => esc_html__( 'Featured Image on Blog Archive Page','talkie'),
					'subtitle' => esc_html__( 'Turn on to display featured images on the blog or archive pages.','talkie'),
					'options'   => array(
						'yes' => esc_html__('On','talkie'),
						'no' => esc_html__('Off','talkie')
					),
					'default'   => esc_html__('yes','talkie')
				),
			)
		));

		Redux::set_section( $this->opt_name, array(
				'title'      => esc_html__( 'Blog Single Post', 'talkie' ),
				'id'         => 'basic',
				'subsection' => true,
				'fields'     => array(

					array(
						'id'        => 'blog_single_page_setting',
						'type'      => 'image_select',
						'title'     => esc_html__( 'Blog Single page Setting','talkie' ),
						'subtitle'  => wp_kses( __( '<br />Choose among these structures (Right Sidebar, Left Sidebar and 1column) for your blog section.<br />To filling these column sections you should go to appearance > widget.<br />And put every widget that you want in these sections.','talkie' ), array( 'br' => array() ) ),
						'options'   => array(
							'1' => array( 'title' => esc_html__( 'Full Width','talkie' ), 'img' => get_template_directory_uri() . '/assets/images/redux/single-column.jpg' ),
							'4' => array( 'title' => esc_html__( 'Right Sidebar','talkie' ), 'img' => get_template_directory_uri() . '/assets/images/redux/right-side.jpg' ),
							'5' => array( 'title' => esc_html__( 'Left Sidebar','talkie' ), 'img' => get_template_directory_uri() . '/assets/images/redux/left-side.jpg' ),
						),
						'default'   => '4',
					),

					array(
						'id'        => 'display_comment',
						'type'      => 'button_set',
						'title'     => esc_html__( 'Comments','talkie'),
						'subtitle' => esc_html__( 'Turn on to display comments.','talkie'),
						'options'   => array(
							'yes' => esc_html__('On','talkie'),
							'no' => esc_html__('Off','talkie')
						),
						'default'   => esc_html__('yes','talkie')
					),

				))
		);

	}
}
